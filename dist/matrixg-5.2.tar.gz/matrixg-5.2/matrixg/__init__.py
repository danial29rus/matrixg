print("""Функция matrixg решает
слау по Gauss and jacoby""")
from .matrixg import *