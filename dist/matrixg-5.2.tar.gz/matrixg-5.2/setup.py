from setuptools import setup

setup(name='matrixg',
      version='5.2',
      description='Solve matrix by Gaussian and Jacoby',
      packages=['matrixg'],
      author_email='shpeka4kaps4@mail.ru',
      zip_safe=False)
