# matrixg
#USAGE
matrixg.matrix_1()