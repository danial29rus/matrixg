from setuptools import setup, find_packages
long_description= '''Python module for solve matrix by gauss and Jacoby'''
requirements=["fraction","numpy","matplotlib","scipy"]
setup(name='matrixg',
      version='1.2',
      url='https://github.com/danial29rus/matrixg',
      license='MIT',
      author='danial29rus',
      author_email='shpeka4kaps4@mail.ru',
      install_requires=requirements,
      zip_safe=False)